# Destiny Explained Studio

Cute 2D cartoon explainers about Destiny 2 lore, built with React + TypeScript + Remotion.
All art is original SVG, drawn in code.

## Install

Requires Node 18+.

    npm install
    npm run dev        # Remotion Studio: live 1080x1920 preview, scrubbable timeline
    npm run render     # writes out/episode1.mp4
    npm run still      # writes out/frame.png (frame 150) for a quick check
    npm run typecheck

The first render downloads a headless Chromium (needs internet once).

## Structure

    src/
      index.ts                  registerRoot
      Root.tsx                  Composition "Episode1" (duration computed from scenes)
      types.ts                  Pose, Cue, SceneDef, EpisodeDef
      project/
        episode1.ts             episode data: scenes, durations, camera, subtitle cues
        timeline.ts             FPS, size, ground line, frame math
      animation/helpers.ts      palette, ink colour, blink()
      characters/Hunter.tsx     idle | talk | walk | jump | resurrect
      characters/Ghost.tsx      floating Ghost, blinking eye, glow
      backgrounds/TravelerSky.tsx
      components/Subtitles.tsx  word-by-word pop, highlight on active word
      components/Effects.tsx    Beam, Sparkles, Flash
      compositions/SceneView.tsx  one scene: camera zoom, fade transition, characters
      compositions/Episode.tsx    lays scenes out back to back + subtitles + audio
    public/                     drop voiceover.mp3 here

## Edit an episode

- Change scene lengths, poses, positions and camera in `src/project/episode1.ts`.
  In Remotion Studio you can also edit the `episode` props JSON in the right panel;
  the total duration updates automatically.
- Subtitles: each cue has `start`/`end` in seconds. Add `words: [{text,start,end}]`
  for exact word timing (e.g. from your TTS or Whisper); otherwise words are spread evenly.
- Voiceover: copy `voiceover.mp3` into `public/` and set `voiceover: 'voiceover.mp3'`.
  Then retime the cues to match.

## Roadmap

1. (this prototype) Preview + MP4 export
2. In-browser editor with `@remotion/player`: scene list, duration sliders, props form
3. Timeline UI (drag to reorder scenes), project save/load as JSON in localStorage
4. Subtitle import (SRT/JSON), waveform view
5. More characters (Warlock, Titan), more locations, more transitions
