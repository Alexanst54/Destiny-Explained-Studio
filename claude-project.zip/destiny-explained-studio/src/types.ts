export type Pose = 'idle' | 'talk' | 'walk' | 'jump' | 'resurrect';

export type Word = {text: string; start: number; end: number};

/** Subtitle cue. Times are in seconds on the episode timeline. */
export type Cue = {text: string; start: number; end: number; words?: Word[]};

export type CameraDef = {
  zoomFrom: number;
  zoomTo: number;
  focusX: number;
  focusY: number;
};

export type SceneDef = {
  id: string;
  title: string;
  durationSec: number;
  hunterPose: Pose;
  /** Hunter feet x at scene start and end (px, 1080 wide). */
  hunterX: [number, number];
  /** Ghost offset from the hunter's feet. */
  ghostOffset: [number, number];
  camera: CameraDef;
};

export type EpisodeDef = {
  title: string;
  /** File inside /public, e.g. "voiceover.mp3". null = no audio. */
  voiceover: string | null;
  cues: Cue[];
  scenes: SceneDef[];
};
