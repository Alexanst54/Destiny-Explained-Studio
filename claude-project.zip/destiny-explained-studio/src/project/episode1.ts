import type {EpisodeDef} from '../types';

export const episode1: EpisodeDef = {
  title: 'Why Can Guardians Come Back to Life?',
  voiceover: null, // e.g. 'voiceover.mp3' after copying it into /public
  cues: [
    {text: 'Guardians die... and come back.', start: 0.3, end: 2.9},
    {
      text: "A tiny Ghost revives them with the Traveler's Light.",
      start: 3.2,
      end: 6.6,
    },
    {text: 'That is why Guardians never stay down!', start: 6.9, end: 9.7},
  ],
  scenes: [
    {
      id: 'intro',
      title: 'Meet the Guardian',
      durationSec: 3,
      hunterPose: 'talk',
      hunterX: [430, 430],
      ghostOffset: [270, -520],
      camera: {zoomFrom: 1, zoomTo: 1.15, focusX: 540, focusY: 1000},
    },
    {
      id: 'walk',
      title: 'Ghost by your side',
      durationSec: 3.5,
      hunterPose: 'walk',
      hunterX: [200, 620],
      ghostOffset: [260, -520],
      camera: {zoomFrom: 1.12, zoomTo: 1, focusX: 540, focusY: 1000},
    },
    {
      id: 'revive',
      title: 'Resurrection',
      durationSec: 3.5,
      hunterPose: 'resurrect',
      hunterX: [540, 540],
      ghostOffset: [0, -600],
      camera: {zoomFrom: 1, zoomTo: 1.25, focusX: 540, focusY: 1150},
    },
  ],
};
