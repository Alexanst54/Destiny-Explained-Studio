import React from 'react';
import {spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {Cue, Word} from '../types';

/** If a cue has no word timestamps, spread its duration evenly across its words. */
const evenWords = (cue: Cue): Word[] => {
  const parts = cue.text.split(/\s+/).filter(Boolean);
  const step = (cue.end - cue.start) / parts.length;
  return parts.map((text, i) => ({
    text,
    start: cue.start + i * step,
    end: cue.start + (i + 1) * step,
  }));
};

export const Subtitles: React.FC<{cues: Cue[]}> = ({cues}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;
  const cue = cues.find((c) => t >= c.start && t < c.end);
  if (!cue) return null;

  const words = cue.words ?? evenWords(cue);
  const pop = spring({
    frame: frame - Math.round(cue.start * fps),
    fps,
    config: {damping: 12, stiffness: 200},
  });

  return (
    <div
      style={{
        position: 'absolute',
        left: 60,
        right: 60,
        top: 1460,
        textAlign: 'center',
        transform: `scale(${0.85 + 0.15 * pop})`,
        opacity: Math.min(1, pop),
      }}
    >
      {words.map((w, i) => {
        const active = t >= w.start && t < w.end;
        return (
          <span
            key={i}
            style={{
              display: 'inline-block',
              margin: '0 10px',
              fontSize: 84,
              lineHeight: 1.15,
              fontWeight: 900,
              fontFamily: "'Baloo 2', 'Nunito', 'Arial Rounded MT Bold', system-ui, sans-serif",
              color: active ? '#ffd27a' : '#ffffff',
              WebkitTextStroke: '12px #2b2540',
              paintOrder: 'stroke fill',
              transform: `scale(${active ? 1.12 : 1})`,
            }}
          >
            {w.text}
          </span>
        );
      })}
    </div>
  );
};
